package com.example.petapp1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class PetfoodActivity extends AppCompatActivity {

    DrawerLayout drawerLayout;
    TextView pageTitle;
    public FirebaseAuth mAuth;
    public FirebaseUser currentUser;
    TextView Logout_btn;
    ImageView Logout_ic;
    TextView Login_btn;
    ImageView Login_ic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_petfood);

        mAuth = FirebaseAuth.getInstance();
        currentUser= mAuth.getCurrentUser();
        drawerLayout=findViewById(R.id.drawer_layout);
        pageTitle = findViewById(R.id.pagename);
        pageTitle.setText("Pet Food");
        Login_btn = findViewById(R.id.login_btn);
        Login_ic = findViewById(R.id.login_ic);
//        currentUser.getUid();

        if(currentUser==null){
            Logout_btn.setVisibility(View.GONE);
            Logout_ic.setVisibility(View.GONE);

        }
        else{
            Login_btn.setVisibility(View.GONE);
            Login_ic.setVisibility(View.GONE);
        }

    }


    public void ClickMenu(View view){
        MainActivity.openDrawer(drawerLayout);

    }
    public void ClickLogo(View view){
        MainActivity.closeDrawer(drawerLayout);
    }

    public void ClickHome(View view){
        MainActivity.redirectActivity(this,MainActivity.class);
    }

    public void clickDonate(View view){
        MainActivity.redirectActivity(this,DonateActivity.class);
    }

    public void clickAdopt(View view){
        MainActivity.redirectActivity(this,AdoptActivity.class);
    }

    public void clickPetfood(View view){
        recreate();
    }

    public void clickFAQs(View view){
        MainActivity.redirectActivity(this,FAQsActivity.class);
    }

    public void clickRegister(View view){
        MainActivity.redirectActivity(this,RegistrationActivity.class);
    }

    public void clickLogout(View view){

        logout();

    }

    public  void logout(){

        if(currentUser == null)
        {
            Toast.makeText(getApplicationContext(),"You Cannot logout until you login",Toast.LENGTH_SHORT).show();
        }else {

            mAuth.signOut();
            startActivity(new Intent(getApplicationContext(), LoginActivity.class));
        }
    }

    public void clickLogin(View view){

        login();

    }

    public  void login(){

        if(currentUser != null)
        {
            Toast.makeText(getApplicationContext(),"You are already logged in",Toast.LENGTH_SHORT).show();
        }else {

            startActivity(new Intent(getApplicationContext(), LoginActivity.class));
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        MainActivity.closeDrawer(drawerLayout);
    }
}